﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Util.Domains
{
    /// <summary>
    /// 测试类
    /// </summary>
   public class Test:EntityBaseGuid
    {
        /// <summary>
        /// 初始化
        /// </summary>
        public Test():this(new Guid())
        {

        }

        /// <summary>
        /// 初始化员工
        /// </summary>
        /// <param name="id"></param>
        public Test(Guid id) : base(id)
        {

        }

        public string Name { get; set; }

        protected override void AddDescriptions()
        {
            AddDescription("Id:" + Id + ",");
            AddDescription("姓名", Name);
        }
    }
}
