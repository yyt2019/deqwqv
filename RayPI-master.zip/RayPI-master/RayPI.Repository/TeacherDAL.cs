﻿using RayPI.Entity;
using System;
using System.Collections.Generic;
using System.Text;
using RayPI.IRepository;

namespace RayPI.Repository
{
    public class TeacherDAL : BaseDAL<Teacher>, ITeacher
    {

    }
}
