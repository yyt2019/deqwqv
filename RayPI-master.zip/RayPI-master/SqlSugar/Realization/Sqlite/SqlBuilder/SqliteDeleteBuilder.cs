﻿namespace SqlSugar
{
    public class SqliteDeleteBuilder : DeleteBuilder
    {

    }
}
