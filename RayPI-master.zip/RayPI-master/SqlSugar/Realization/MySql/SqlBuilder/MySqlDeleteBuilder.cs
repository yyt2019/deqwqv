﻿namespace SqlSugar
{
    public class MySqlDeleteBuilder : DeleteBuilder
    {

    }
}
