﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SqlSugar
{
    public enum DateType
    {
        Year = 1,
        Month = 2,
        Day =3,
        Hour = 4,
        Second=5,
        Minute=6,
        Millisecond=7
    }
}
