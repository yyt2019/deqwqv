﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
namespace SqlSugar
{
    public class ExpResolveAccessory
    {
        protected List<SugarParameter> _Parameters;
        protected ExpressionResult _Result;
    }
}
