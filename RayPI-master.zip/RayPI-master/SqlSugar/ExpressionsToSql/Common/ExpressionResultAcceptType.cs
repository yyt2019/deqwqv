﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace SqlSugar
{
    public enum ExpressionResultAppendType
    {
        AppendResult=0,
        AppendTempDate=1
    }
}
