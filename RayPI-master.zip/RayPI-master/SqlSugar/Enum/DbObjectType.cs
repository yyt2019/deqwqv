﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SqlSugar
{
    public enum DbObjectType
    {
        Table = 0,
        View = 1,
        All = 2
    }
}
