﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SqlSugar
{
    public enum ApplyType
    {
        Cross = 1,
        Outer = 2
    }
}
