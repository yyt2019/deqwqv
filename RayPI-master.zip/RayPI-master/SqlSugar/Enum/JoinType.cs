﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SqlSugar
{
    public enum JoinType
    {
        Inner = 0,
        Left = 1,
        Right = 2
    }
}
