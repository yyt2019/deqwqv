﻿using RayPI.Entity;

namespace RayPI.IRepository
{
    public interface ITeacher:IBase<Teacher>
    {
       
    }
}
